package com.example.util

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

enum class SoundEffect {
    TAP,                  // Soft subtle button tap
    OPTION_SELECT,        // MCQ Option selection chime
    NAV_NEXT,             // Next question upward tone
    NAV_PREV,             // Prev question downward tone
    TEST_SUBMIT_LONG,     // Long celebratory test submission chime arpeggio
    LOGIN_SUCCESS,        // Pleasant welcoming login chime chord
    REFRESH,              // Refresh flutter chime
    TAB_SWITCH,           // Tab switch airy tick
    ERROR_OR_DELETE,      // Soft warning low tone
    SWITCH_TOGGLE         // Switch on/off soft pop
}

/**
 * SoundManager provides soft, acoustic-like, non-intrusive sound effects for all app interactions.
 * - Routes strictly through AudioAttributes.USAGE_MEDIA / CONTENT_TYPE_MUSIC (Media Volume)
 *   so users can easily increase or decrease volume with standard device volume keys.
 * - Provides a 1-click global mute / unmute toggle with persistent preferences.
 * - Generates smooth ADSR-enveloped synthetic audio (zero harsh clicks or pops).
 * - Includes a dedicated long, celebratory musical chime for Test Submission.
 */
object SoundManager {
    private const val PREFS_NAME = "test_mitra_sound_prefs"
    private const val KEY_MUTED = "is_sound_muted"
    private const val SAMPLE_RATE = 44100

    private val _isMutedState = MutableStateFlow(false)
    val isMutedState: StateFlow<Boolean> = _isMutedState.asStateFlow()

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    // Cache of pre-synthesized PCM audio buffers for latency-free playback
    private val soundBuffers = mutableMapOf<SoundEffect, ShortArray>()

    fun init(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        _isMutedState.value = prefs.getBoolean(KEY_MUTED, false)

        scope.launch {
            preloadAllSounds()
        }
    }

    fun toggleMute(context: Context) {
        val newMuted = !_isMutedState.value
        _isMutedState.value = newMuted
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_MUTED, newMuted).apply()

        // If unmuting, give a very soft confirmation tap
        if (!newMuted) {
            playSound(SoundEffect.TAP)
        }
    }

    fun setMuted(muted: Boolean, context: Context) {
        if (_isMutedState.value == muted) return
        _isMutedState.value = muted
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_MUTED, muted).apply()
    }

    fun isMuted(): Boolean = _isMutedState.value

    fun playSound(effect: SoundEffect) {
        if (_isMutedState.value) return

        scope.launch {
            val buffer = soundBuffers[effect] ?: generateSound(effect).also {
                soundBuffers[effect] = it
            }
            playPcmBuffer(buffer)
        }
    }

    private fun preloadAllSounds() {
        SoundEffect.entries.forEach { effect ->
            if (!soundBuffers.containsKey(effect)) {
                soundBuffers[effect] = generateSound(effect)
            }
        }
    }

    private fun playPcmBuffer(buffer: ShortArray) {
        try {
            val audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()

            val audioFormat = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(SAMPLE_RATE)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build()

            val track = AudioTrack.Builder()
                .setAudioAttributes(audioAttributes)
                .setAudioFormat(audioFormat)
                .setBufferSizeInBytes(buffer.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            track.write(buffer, 0, buffer.size)
            track.play()

            val durationMs = (buffer.size * 1000L) / SAMPLE_RATE
            scope.launch {
                delay(durationMs + 60)
                try {
                    track.stop()
                    track.release()
                } catch (_: Exception) {}
            }
        } catch (_: Exception) {
            // Audio output fallback gracefully
        }
    }

    // ---------------- Waveform Synthesizers (Soft & Natural) ----------------

    private fun generateSound(effect: SoundEffect): ShortArray {
        return when (effect) {
            SoundEffect.TAP -> generateTapSound()
            SoundEffect.OPTION_SELECT -> generateOptionSelectSound()
            SoundEffect.NAV_NEXT -> generateNavNextSound()
            SoundEffect.NAV_PREV -> generateNavPrevSound()
            SoundEffect.TEST_SUBMIT_LONG -> generateTestSubmitLongSound()
            SoundEffect.LOGIN_SUCCESS -> generateLoginSuccessSound()
            SoundEffect.REFRESH -> generateRefreshSound()
            SoundEffect.TAB_SWITCH -> generateTabSwitchSound()
            SoundEffect.ERROR_OR_DELETE -> generateErrorOrDeleteSound()
            SoundEffect.SWITCH_TOGGLE -> generateSwitchToggleSound()
        }
    }

    /**
     * Soft general button tap (50ms).
     */
    private fun generateTapSound(): ShortArray {
        val durationMs = 50
        val numSamples = (SAMPLE_RATE * durationMs) / 1000
        val buffer = ShortArray(numSamples)
        val freq = 520.0
        val maxAmp = 10000.0

        for (i in 0 until numSamples) {
            val t = i.toDouble() / SAMPLE_RATE
            val progress = i.toDouble() / numSamples
            // Fast 4ms attack, smooth exponential decay
            val attack = min(1.0, (i.toDouble() / (SAMPLE_RATE * 0.004)))
            val decay = exp(-progress * 5.0)
            val envelope = attack * decay
            val sample = sin(2.0 * PI * freq * t) * maxAmp * envelope
            buffer[i] = sample.toInt().toShort()
        }
        return buffer
    }

    /**
     * Gentle affirmative dual-tone harmonic chime for option selection (110ms).
     */
    private fun generateOptionSelectSound(): ShortArray {
        val durationMs = 110
        val numSamples = (SAMPLE_RATE * durationMs) / 1000
        val buffer = ShortArray(numSamples)
        val f1 = 659.25 // E5
        val f2 = 880.00 // A5
        val maxAmp = 11000.0

        for (i in 0 until numSamples) {
            val t = i.toDouble() / SAMPLE_RATE
            val progress = i.toDouble() / numSamples
            val attack = min(1.0, (i.toDouble() / (SAMPLE_RATE * 0.008)))
            val decay = exp(-progress * 4.2)
            val envelope = attack * decay
            val sample = (0.65 * sin(2.0 * PI * f1 * t) + 0.35 * sin(2.0 * PI * f2 * t)) * maxAmp * envelope
            buffer[i] = sample.toInt().toShort()
        }
        return buffer
    }

    /**
     * Upward smooth chirp for "Next" question navigation (90ms).
     */
    private fun generateNavNextSound(): ShortArray {
        val durationMs = 90
        val numSamples = (SAMPLE_RATE * durationMs) / 1000
        val buffer = ShortArray(numSamples)
        val startFreq = 523.25 // C5
        val endFreq = 783.99   // G5
        val maxAmp = 9500.0

        for (i in 0 until numSamples) {
            val progress = i.toDouble() / numSamples
            val currentFreq = startFreq + (endFreq - startFreq) * progress
            val t = i.toDouble() / SAMPLE_RATE
            val attack = min(1.0, (i.toDouble() / (SAMPLE_RATE * 0.008)))
            val decay = exp(-progress * 3.5)
            val envelope = attack * decay
            val sample = sin(2.0 * PI * currentFreq * t) * maxAmp * envelope
            buffer[i] = sample.toInt().toShort()
        }
        return buffer
    }

    /**
     * Downward smooth chirp for "Prev" question navigation (90ms).
     */
    private fun generateNavPrevSound(): ShortArray {
        val durationMs = 90
        val numSamples = (SAMPLE_RATE * durationMs) / 1000
        val buffer = ShortArray(numSamples)
        val startFreq = 783.99 // G5
        val endFreq = 523.25   // C5
        val maxAmp = 9500.0

        for (i in 0 until numSamples) {
            val progress = i.toDouble() / numSamples
            val currentFreq = startFreq + (endFreq - startFreq) * progress
            val t = i.toDouble() / SAMPLE_RATE
            val attack = min(1.0, (i.toDouble() / (SAMPLE_RATE * 0.008)))
            val decay = exp(-progress * 3.5)
            val envelope = attack * decay
            val sample = sin(2.0 * PI * currentFreq * t) * maxAmp * envelope
            buffer[i] = sample.toInt().toShort()
        }
        return buffer
    }

    /**
     * Distinct, long, celebratory harmonic arpeggio bell sequence for Test Submit (~1.5 seconds).
     * Melodic notes: C5 (523Hz) -> E5 (659Hz) -> G5 (784Hz) -> C6 (1046Hz) with rich resonant decay.
     */
    private fun generateTestSubmitLongSound(): ShortArray {
        val durationMs = 1500
        val numSamples = (SAMPLE_RATE * durationMs) / 1000
        val buffer = ShortArray(numSamples)

        val notes = listOf(
            Triple(0, 523.25, 0.28),    // C5 at 0ms
            Triple(180, 659.25, 0.30),  // E5 at 180ms
            Triple(360, 783.99, 0.32),  // G5 at 360ms
            Triple(540, 1046.50, 0.40)  // C6 at 540ms (rings out till end)
        )

        val maxAmp = 12500.0

        for (i in 0 until numSamples) {
            val currentMs = (i * 1000) / SAMPLE_RATE
            var combinedSample = 0.0

            for ((startMs, freq, weight) in notes) {
                if (currentMs >= startMs) {
                    val noteSampleIndex = i - (startMs * SAMPLE_RATE / 1000)
                    val noteDurationMs = durationMs - startMs
                    val noteTotalSamples = (SAMPLE_RATE * noteDurationMs) / 1000
                    val noteProgress = noteSampleIndex.toDouble() / noteTotalSamples
                    val t = noteSampleIndex.toDouble() / SAMPLE_RATE

                    val attack = min(1.0, noteSampleIndex.toDouble() / (SAMPLE_RATE * 0.015))
                    val decay = exp(-noteProgress * 3.0)
                    val envelope = attack * decay

                    // Blend fundamental with harmonic octave for crystal bell acoustic quality
                    val tone = 0.75 * sin(2.0 * PI * freq * t) + 0.25 * sin(2.0 * PI * (freq * 2.0) * t)
                    combinedSample += tone * weight * envelope
                }
            }

            val finalVal = (combinedSample * maxAmp).coerceIn(-32767.0, 32767.0)
            buffer[i] = finalVal.toInt().toShort()
        }
        return buffer
    }

    /**
     * Welcoming harmonic major triad for successful login (380ms).
     */
    private fun generateLoginSuccessSound(): ShortArray {
        val durationMs = 380
        val numSamples = (SAMPLE_RATE * durationMs) / 1000
        val buffer = ShortArray(numSamples)
        val f1 = 523.25 // C5
        val f2 = 659.25 // E5
        val f3 = 783.99 // G5
        val maxAmp = 11000.0

        for (i in 0 until numSamples) {
            val t = i.toDouble() / SAMPLE_RATE
            val progress = i.toDouble() / numSamples
            val attack = min(1.0, (i.toDouble() / (SAMPLE_RATE * 0.02)))
            val decay = exp(-progress * 3.5)
            val envelope = attack * decay
            val tone = (0.4 * sin(2.0 * PI * f1 * t) + 0.35 * sin(2.0 * PI * f2 * t) + 0.25 * sin(2.0 * PI * f3 * t))
            buffer[i] = (tone * maxAmp * envelope).toInt().toShort()
        }
        return buffer
    }

    /**
     * Airy flutter chime for Refresh (120ms).
     */
    private fun generateRefreshSound(): ShortArray {
        val durationMs = 120
        val numSamples = (SAMPLE_RATE * durationMs) / 1000
        val buffer = ShortArray(numSamples)
        val maxAmp = 9500.0

        for (i in 0 until numSamples) {
            val t = i.toDouble() / SAMPLE_RATE
            val progress = i.toDouble() / numSamples
            val freq = 650.0 + 200.0 * sin(PI * progress)
            val attack = min(1.0, (i.toDouble() / (SAMPLE_RATE * 0.01)))
            val decay = exp(-progress * 3.8)
            val envelope = attack * decay
            val sample = sin(2.0 * PI * freq * t) * maxAmp * envelope
            buffer[i] = sample.toInt().toShort()
        }
        return buffer
    }

    /**
     * Ultra-soft airy tick for tab switching (40ms).
     */
    private fun generateTabSwitchSound(): ShortArray {
        val durationMs = 40
        val numSamples = (SAMPLE_RATE * durationMs) / 1000
        val buffer = ShortArray(numSamples)
        val freq = 640.0
        val maxAmp = 7500.0

        for (i in 0 until numSamples) {
            val t = i.toDouble() / SAMPLE_RATE
            val progress = i.toDouble() / numSamples
            val attack = min(1.0, (i.toDouble() / (SAMPLE_RATE * 0.003)))
            val decay = exp(-progress * 6.0)
            val envelope = attack * decay
            val sample = sin(2.0 * PI * freq * t) * maxAmp * envelope
            buffer[i] = sample.toInt().toShort()
        }
        return buffer
    }

    /**
     * Gentle soft low double-tone for delete or warning (180ms).
     */
    private fun generateErrorOrDeleteSound(): ShortArray {
        val durationMs = 180
        val numSamples = (SAMPLE_RATE * durationMs) / 1000
        val buffer = ShortArray(numSamples)
        val halfSamples = numSamples / 2
        val maxAmp = 9000.0

        for (i in 0 until numSamples) {
            val t = i.toDouble() / SAMPLE_RATE
            val freq = if (i < halfSamples) 340.0 else 270.0
            val subProgress = if (i < halfSamples) i.toDouble() / halfSamples else (i - halfSamples).toDouble() / halfSamples
            val attack = min(1.0, subProgress / 0.1)
            val decay = exp(-subProgress * 4.5)
            val envelope = attack * decay
            val sample = sin(2.0 * PI * freq * t) * maxAmp * envelope
            buffer[i] = sample.toInt().toShort()
        }
        return buffer
    }

    /**
     * Soft pop for toggle switches (45ms).
     */
    private fun generateSwitchToggleSound(): ShortArray {
        val durationMs = 45
        val numSamples = (SAMPLE_RATE * durationMs) / 1000
        val buffer = ShortArray(numSamples)
        val freq = 480.0
        val maxAmp = 8000.0

        for (i in 0 until numSamples) {
            val t = i.toDouble() / SAMPLE_RATE
            val progress = i.toDouble() / numSamples
            val attack = min(1.0, (i.toDouble() / (SAMPLE_RATE * 0.003)))
            val decay = exp(-progress * 5.5)
            val envelope = attack * decay
            val sample = sin(2.0 * PI * freq * t) * maxAmp * envelope
            buffer[i] = sample.toInt().toShort()
        }
        return buffer
    }
}
